<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="az">
<context>
    <name>KvManager::AboutDialog</name>
    <message>
        <location filename="../../about.ui" line="175"/>
        <source>License</source>
        <translation>Lisenziya</translation>
    </message>
</context>
<context>
    <name>KvManager::KvantumManager</name>
    <message>
        <location filename="../../kvantummanager.ui" line="12"/>
        <source>Kvantum Manager</source>
        <translation>Kavntum İdarəedici</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="38"/>
        <source>Install/Update Theme</source>
        <translation>Mövzu quraşdırın/yeniləyin</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="44"/>
        <source>&lt;center&gt;&lt;b&gt;&lt;i&gt;Kvantum&lt;/i&gt;&lt;/b&gt; comes with many themes but external themes can also be installed for being used by it. Here you could choose a theme folder and then press the button below to install it in your Home.&lt;/center&gt;</source>
        <translation>&lt;center&gt;&lt;b&gt;&lt;i&gt;Kvantum&lt;/i&gt;&lt;/b&gt; bir çox hazır quraşdırılmış mövzular ilə təqdim olunsa da xarici mövzuları da quraşdırıb istifadə etmək mümkündür. Buradan mövzu qovluğunu seçdikdən sonra aşağıdakı düymə ilə onu sistemə quraşdırmaq olar.&lt;/center&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="76"/>
        <source>Select a Kvantum
theme folder</source>
        <translation>Kvantum mövzu
qovluğunu seçin</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="113"/>
        <source>Add this theme to the list of themes that
Kvantum can use in addition to its own themes.</source>
        <translation>Bu mövzunu Kvantum-un istifadə edə
biləcəyi mövzular siyahısına əlavə edin.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="117"/>
        <source>Install this theme</source>
        <translation>Bu mövzunu quraşdırın</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="138"/>
        <source>Change/Delete Theme</source>
        <translation>Mövzunu dəyişin/silin</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="144"/>
        <source>Select a theme:</source>
        <translation>Mövzu seçin:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="191"/>
        <source>Delete this theme</source>
        <translation>Bu mövzunu silin</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="198"/>
        <source>Make Kvantum use this theme!

A disabled button means that
the theme is already used.</source>
        <translation>Bu mövzunu Kvantum-da istifadə edin!

Aktiv olmayan düymə o deməkdir ki,
hazırkı mövzu artıq istifadə olunur.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="204"/>
        <source>Use this theme</source>
        <translation>Mövzunu istifadə edin</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="257"/>
        <source>Configure Active Theme</source>
        <translation>Aktiv mövzunu ayarlayın</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="321"/>
        <source>Revert to the default (root)
settings of this theme.
(Ctrl+Z)</source>
        <translation>Mövzu ayarlarını ilkin (kök)
vəziyyətinə qaytarın.
(Ctrl+Z)</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="326"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Revert to the default (root) settings of this theme!&lt;/p&gt;&lt;p&gt;When clicked and confirmed, all changes to the configuration will be lost but the probable customized SVG file will remain intact.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bu mövzunun ayarlarını ilkin (kök) vəziyyətinə qaytarın!&lt;/p&gt;&lt;p&gt; Klik etdikdən və təsdiqlədikdən sonra ayarlarda etdiyiniz bütün dəyişikliklər itiriləcək, lakin tətbiq edilmiş SVG faylı dəyişməz qalacaq.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="329"/>
        <source>Restore</source>
        <translation>Bərpa edin</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="332"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="342"/>
        <source>Save this configuration
(Ctrl+S)</source>
        <translation>Bu ayarları saxlayın
(Ctrl+S)</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="346"/>
        <location filename="../../kvantummanager.ui" line="2180"/>
        <source>Save</source>
        <translation>Saxlayın</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="349"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="356"/>
        <source>Safe Settings</source>
        <translation>Təhlükəsiz ayarlar</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="369"/>
        <source>Hacks</source>
        <translation>Düzəlişlər</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="396"/>
        <source>Transparent Dolphin view</source>
        <translation>Şəfaf Dolphin görünüşü</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="424"/>
        <source>Normal font for default push buttons</source>
        <translation>Standart düymələr üçün adi mətn</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="444"/>
        <source>Merge PCManFM-qt&apos;s sidepane with its surroundings.

Under LXQt, it needs logging out and in or closing
PCManFM-qt and then, stopping and starting Desktop
with LXQt Session Settings.</source>
        <translation>PCManFM-qt yan panelini kənarları ilə birləşçdirmək.

LXQt mühitində PCManFM-qt-dən çıxdıqdan və ya bağladıqdan
sonra LXQt sessiyası ayarları ilə iş masasını dayandırmaq və
yenidən başlatmaq lazımdır.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="451"/>
        <source>Transparent sidepane for PCManFM-qt</source>
        <translation>PCManFM-qt üçün şəffaf yan panel</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="466"/>
        <source>Iconless push buttons</source>
        <translation>Nişanlarsız düymələr</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="473"/>
        <source>Merge PCManFM-qt&apos;s view with its surroundings.

Under LXQt, it needs logging out and in or closing
PCManFM-qt and then, stopping and starting Desktop
with LXQt Session Settings.</source>
        <translation>PCManFM-qt görünüşünü kənarları ilə birləşdirmək.

LXQt mühitində PCManFM-qt-dən çıxdıqdan və ya onu
bağladıqdan sonraLXQt sessiyası ayarları ilə iş masasını
dayandırmaq və yenidən başlatmaq lazımdır.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="480"/>
        <source>Transparent view for PCManFM-qt</source>
        <translation>PCManFM-qt üçün şəffaf görünüş</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="495"/>
        <source>Iconless menus</source>
        <translation>Nişanlarsız menyu</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="510"/>
        <source>Blur explicitly translucent windows</source>
        <translation>Yarımşəffaf pəncərələri bulanıqlaşdırmaq</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="524"/>
        <source>Single top toolbar</source>
        <translation>Yalnız üst alətlər paneli</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="554"/>
        <source>Do not draw any background for KTitles.</source>
        <translation>KTitles-da fonu göstərməmək.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="557"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Do not draw any background for KTitles?&lt;/p&gt;&lt;p&gt;Ktitles are used by some KDE applications to show different sections in configuration dialogs.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;KTitles üçün heç bir arxa fon görünməsin?&lt;/p&gt;&lt;p&gt;Ktitles bəzi KDE tətbiqləri tərəfindən tənzimləmə dialoqlarında müxtəlif bölmələri göstərmək üçün istifadə olunur. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="560"/>
        <source>Transparent KTitle label</source>
        <translation>Şəffaf KTitle etiketləri</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="567"/>
        <source>Do not tint selected label icons with
the highlight color!</source>
        <translation>Seçilmiş etiket nişanları vurğulama
rəngi ilə rənglənməsin!</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="571"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;By default, selected label icons are tinted by the highlight color.&lt;/p&gt;&lt;p&gt;Checking this box removes the tint.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;İlkin olaraq seçilmiş etiket nişanları vurğulama rəngi ilə rənglənir.&lt;/p&gt;&lt;p&gt;Bu xananı işarələmək vurğulama rəngini ləğv edir.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="574"/>
        <source>No selection tint</source>
        <translation>Vurğulama rəngi yox</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="581"/>
        <source>Do not draw any background for (KDE) menu titles.
(Needs Logging out and in for Plasma menus.)</source>
        <translation>KDE mühitində menyu başlıqlarında fon görünməsin.
(Plasma menyuları üçün çıxmaq və daxil olmaq lazımdır.)</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="585"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Do not draw any background for (KDE) menu titles?&lt;/p&gt;&lt;p&gt;Menu titles are like menu separators but with icon and text.&lt;/p&gt;&lt;p&gt;This needs Logging out and in for KDE Plasma menus. For LXQt panel, a panel restart with &lt;span style=&quot; font-style:italic;&quot;&gt;Session Settings &lt;/span&gt;is enough.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;KDE menyu başlıqları üçün heç bir fon göstərilməsin?&lt;/p&gt;&lt;p&gt;Menyu başlıqları menyu ayırıcıları kimidir lakin nişan və mətndən ibarətdir.&lt;/p&gt;&lt;p&gt;Dəyişikliklərin qüvvəyə minməsi üçün KDE Plasma-nı yenidən başlatmaq lazımdır. LXQt paneli üçün onu &lt;span style=&quot; font-style:italic;&quot;&gt;Sessiya ayarları &lt;/span&gt;ilə başlatmaq kifayətdir.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="588"/>
        <source>Transparent menu title</source>
        <translation>Şəffaf menyu başlığı</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="651"/>
        <source>Tint label icons on mouseover by </source>
        <translation>Kursor etiket nişanları üzərində olduqda onlar rənglənsin </translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="665"/>
        <location filename="../../kvantummanager.ui" line="712"/>
        <location filename="../../kvantummanager.ui" line="1093"/>
        <location filename="../../kvantummanager.ui" line="1129"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="611"/>
        <source>Respect dark themes</source>
        <translation>Tünd mövzulara uyğunlaşdırın</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="689"/>
        <location filename="../../kvantummanager.ui" line="704"/>
        <source>Useful with monochrome icon sets and
when the opacity of disabled icons is not
reduced by other means.</source>
        <translation>Tək rəngli nişan dəstləri üçn və söndürülmüş
nişanların qeyri-şəffaflığı başqa yollarla 
azaldılmadığında faydalıdır.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="694"/>
        <location filename="../../kvantummanager.ui" line="709"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Useful with monochrome icon sets and when the opacity of disabled icons is not reduced by other means.&lt;/p&gt;&lt;p&gt;KDE automatically reduces the opacity of disabled icons. Therefore, this option might be useful rather under other desktop environments.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tək rəngli nişan dəstləri və söndürülmüş nişanların qeyri-şəffaflığı başqa yollarla azaldılmadığında faydalıdır.&lt;/p&gt;&lt;p&gt;KDE söndürülmüş nişanların qeyri-şəffaflığını avtomatik olaraq azaldır. Buna görə də bu parametr başqa iş masası mühitlərində faydalı ola bilər.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="697"/>
        <source>Opacity of disabled icons:</source>
        <translation>Söndürülmüş nişanıarın qeyri-şəffaflığı:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="630"/>
        <source>Show size grips of dialogs and statusbars
as far as possible.</source>
        <translation>Mümkün olduqda dialoqların və vəziyyət 
çubuqlarının ölçü tutacaqlarını göstərmək.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="634"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Show size grips of dialogs and statusbars as far as possible?&lt;/p&gt;&lt;p&gt;By default, the application decides whether they should be shown, but this hack could be useful for resizing windows easily when there is no window border.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Mümkün olduqda dialoqlarda və vəziyyət çubuqlarında ölçü tutacaqları göstərilsin?&lt;/p&gt;&lt;p&gt;İlkin olaraq bu tətbiq onların harada göstəriləcəyini müəyyən edir, lakin bu düzəliş pəncərə çərçivəsi olmadıqda onun ölçüsünü dəyişmə bilmək üçün faydalı ola bilər.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="637"/>
        <source>Force size grips</source>
        <translation>Ölçünü dəyişmək üçün tutacağı göstərmək</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="750"/>
        <source>LXQt main menu icon size:</source>
        <translation>LXQt əsas menyusunda nişan ölçüsü:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="765"/>
        <location filename="../../kvantummanager.ui" line="1266"/>
        <location filename="../../kvantummanager.ui" line="1304"/>
        <location filename="../../kvantummanager.ui" line="1334"/>
        <location filename="../../kvantummanager.ui" line="1371"/>
        <location filename="../../kvantummanager.ui" line="1399"/>
        <location filename="../../kvantummanager.ui" line="1425"/>
        <location filename="../../kvantummanager.ui" line="1455"/>
        <location filename="../../kvantummanager.ui" line="1483"/>
        <location filename="../../kvantummanager.ui" line="1518"/>
        <source> px</source>
        <translation> piksel</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="779"/>
        <source>Compositing &amp;&amp; General Look</source>
        <translation>Birləşmələr və əsas görünüş</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="978"/>
        <source>Has effect only when there is a translucent SVG background
for windows or the window opacity is reduced (see below).</source>
        <translation>Yalnız pəncərələr üçün SVG arxa fonu yarımşəffaf olduqda
və ya pəncərə qeyri-şəffaflığı azaldıqda təsirli olur (aşağı bax).</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="998"/>
        <source>Opaque apps:</source>
        <translation>Qeyri-şəffaf tətbiqlər:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="785"/>
        <source>If checked, menus, tooltips and windows
will not have translucency or shadow.

If this is disabled, see:
Miscellaneous → Respect current DE if possible</source>
        <translation>Bu xana işarələndikdə menyular, pəncərələr və alət 
ipuclarında qeyri-şəffaflıq və kölgələmə olmayacaq.

Xana işərələnibsə, aşağı bax:
Müxtəlif → Mümkün olduqda mühitə uyğunlaşdırmaq</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="227"/>
        <source>&lt;br&gt;&lt;br&gt;Since &lt;b&gt;&lt;i&gt;Kvantum&lt;/i&gt;&lt;/b&gt; is independent of all desktop environments, you first need to &lt;i&gt;activate&lt;/i&gt; it with a Qt platform integration program. KDE and LXQt provide simple tools for changing the active Qt style plugin. With other platforms, you need a Qt configuration tool.&lt;br/&gt;&lt;br/&gt;Under KDE, also select and apply the color scheme of this theme because some KDE applications may get their colors directly from the KDE color scheme.&lt;br/&gt;&lt;br/&gt;Running applications will get the new theme after being closed and reopened. Logging out and in would be good for all KDE/LXQt parts to see it completely.</source>
        <translation>&lt;br&gt;&lt;br&gt;Since &lt;b&gt;&lt;i&gt;Kvantum&lt;/i&gt;&lt;/b&gt; heç bir iş masası mühitindən asılı deyil, öncə onu Qt platformasına inteqrasiya edilmiş proqram ilə aktiv etmək lazımdır. KDE və LXQt Qt üslubunda plaqini aktiv etmək üçün sadə alətlər təqdim edir. Başqa platformalarda Qt tənzimləmə alətləri lazımdır.&lt;br/&gt;&lt;br/&gt;KDE mühitində həmçinin bu mövzunun rəng sxemini seçin və tətbiq edin, çünki bəzi KDE tətbiqləri rənglərini birbaşa KDE rəng sxemindən ala bilər.&lt;br/&gt;&lt;br/&gt;İşləyən tətbiqlər bağlandıqdan və yenidən başladıldıqdan sonra yeni mövzunu tətbiq edəcək. Yeni mövzunun bütün KDE/LXQt hissələri ilə uyğunluğunu görmək üçün onları yenidən başlatmaq daha yaxşı olardı.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="531"/>
        <source>By default, both active and inactive translucent windows
will be blurred if blurring is enabled.</source>
        <translation>Əgər bulanıqlıq aktiv edilərsə, standart olaraq aktiv və 
qeyri-aktiv yarımşəffəf pəncərələr bulanıq görünəcək.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="535"/>
        <source>No blurring for inactive windows</source>
        <translation>Qeyri-aktiv pəncərələr bulanıq olmasın</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="542"/>
        <source>By default, vertical toolbars are not styled.

If this is disabled, see the above option.</source>
        <translation>İlkin olaraq, şaquli alətlər paneli heç bir üslubda deyil.

Əgər bu söndürülübsə, yuxarıdakı parametrə baxın.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="547"/>
        <source>Style vertical toolbars</source>
        <translation>Şaquli alətlər panelini üslublaşdırın</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="595"/>
        <source>If checked, the contents of a form will be
horizontally centered as far as possible.</source>
        <translation>Xana işarələnərsə forma tərkibləri mümkün
olduqda üfüqi olaraq mərkəzdə yerləşdiriləcək.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="599"/>
        <source>Centered form layouts</source>
        <translation>Forma tərkiblərini mərkəzləşdirmək</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="618"/>
        <source>You might see annoying artifacts that are caused
by bugs in Qt&apos;s handling of non-integer scaling
with window translucency or gradient.</source>
        <translation>Bəzi arzuolunmaz artefaktlır ilə qarşılaşa bilərsiniz.
Buna səbəb yarımşəffaf və qradientli pəncərələrin
Qt ilə kəsrli miqyaslaması ola bilər.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="623"/>
        <source>Disable translucency with non-integer scaling</source>
        <translation>Kəsrli miqyaslama zamanı yarımşəffaflığı söndürmək</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="675"/>
        <source>By default, the scroll slider jumps to a position
when the scrollbar is left clicked.

If this is disabled, see:
Miscellaneous → Respect current DE if possible</source>
        <translation>Standart olaraq sol düymə ilə üzərinə vurduqda 
sürüşdürmə çubuğu mövqeyini dəyişirş

Əgər bu söndürülübsə, baxın:
Müxtəlif → Hazırkı iş masası mühitinə uyğunlaşdırın</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="682"/>
        <source>Scroll jump with middle click</source>
        <translation>Orta düymə ilə sürüşdürmək</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="728"/>
        <source>Scroll some scrollable widgets by flicking them
with the left mouse button.

Warning: Qt&apos;s kinetic scrolling has bugs and may
seriously interfere with other jobs.</source>
        <translation>Sol siçan düyməsi ilə yüngülcə vurmaqla
sürüşdürüləbilən vidjeti sürşdürmək olar.

Xəbərdarlıq: Qt-nin kinetik sürüşdürməsi
xətalıdır və işlərinizə mənfi təsir edə bilər.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="735"/>
        <source>Kinetic scrolling</source>
        <translation>Kinetik sürüşdürmə</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="742"/>
        <location filename="../../kvantummanager.ui" line="757"/>
        <source>Has effect only when the main menu is NOT styled by LXQt.

Values less than 16 mean the default menu icon size.

Needs LXQt panel to be restarted either by &quot;Session Settings&quot;
or through logging out and in again.</source>
        <translation>Əsas menyu LXQt tərəfindən üslublandırılmazsa tətbiq edilir.

16-da az dəyər standart menyu nişan ölçüsü hesab edilir.

LXQt panelini həm &quot;Sessiya ayarları&quot;, həm də sessiyadan
çıxıb yenidən daxil olmaqla yenidən başlada bilərsiniz.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="792"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, menus, tooltips and windows will not have translucency or shadow.&lt;/p&gt;&lt;p&gt;When unchecked, translucency and shadow will be available if there are appropriate elements in the theme&apos;s SVG file.&lt;/p&gt;&lt;p&gt;If this is disabled, see Miscellaneous → Respect current DE if possible.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Əgər bu xana işarələnərsə menyularda, alət ipuclarında və pəncərələrində yarımşəffaflıq və kölgə olmayacaq. &lt;/p&gt;&lt;p&gt;Əgər xana işarələnməzsə yarımşəffaflıq və kölgə mövzunun SVG faylında uyğun elementlər olarsa əlçatan olacaq.&lt;/p&gt;&lt;p&gt;Əgər söndürülbsə Müxtəlif → Mümkün olduqda cari iş masasına uyğunlaşdırmaq menyusuna baxın.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="795"/>
        <source>Disable composite effects</source>
        <translation>Kompozit effektlərini söndürmək</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="804"/>
        <source>If blurring is enabled, these values set the corner
radii for blurring translucent menus and tooltips
that have rounded corners.

Usually, a value of 2 is enough.</source>
        <translation>Əgər bulanıqlıq aktiv edilərsə, bu dəyərlər yuvarlaq 
kənarlara malik yarımşəffaf menyular və alət ipuclarını 
bulanıqlaşdırmaq üçün künc radiuslarını təyin edir.

Adi halda 2 dəyəri kifayətdir.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="811"/>
        <source>Blur Corner Radius</source>
        <translation>Bulanıq künc radiusu</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="824"/>
        <source>Menu:</source>
        <translation>Menyu:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="831"/>
        <source>Tooltip:</source>
        <translation>Alət ipucu:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="855"/>
        <source>Contrast Effect</source>
        <translation>Kontrast effekti</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="861"/>
        <source>Saturation:</source>
        <translation>Doyumluluq:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="868"/>
        <source>Intensity:</source>
        <translation>İntensivlik:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="875"/>
        <source>Contrast:</source>
        <translation>Kontrast:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="952"/>
        <source>Needs KDE blur effect, a graphic card that supports it,
and translucent menu/tooltip SVG elements.

Automatically checked if window blurring is enabled.</source>
        <translation>KDE bulanqılıq effektinin, onu dəstəkləyən video karta
və yarımşəffaf menyu/alət ipucu SVG elementlərinə 
ehtiyacı var.

Pəncərə bulanıqlıq effekti aktiv olduqda xana 
avtomatik işarələnir.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="958"/>
        <source>Blurring for menus and tooltips</source>
        <translation>Menyular və alət ipucları üçün bulanıqlıq</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="965"/>
        <source>Do not draw shadows for menus and tooltips.

This may be useful under DEs that give
shadow to menus and tooltips.</source>
        <translation>Menyular və alət ipucları kolgələri göstərilməsin.

Bu, menyular və alət ipuclarında kölgələri
göstərən iş masası mühitlərində faydalıdır.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="971"/>
        <source>Shadowless menus and tooltips</source>
        <translation>Kölgəsiz menyular və alət ipucları</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="982"/>
        <source>Translucent windows</source>
        <translation>Yarımşəffaf pəncərələr</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1060"/>
        <source>Reduce window opacity by</source>
        <translation>Pəncərə qeyri-şəffaflığını azaltmaq</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1106"/>
        <source>Reduce menu opacity by</source>
        <translation>Menyu qeyri-şəffaflığının azalma faizi</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1144"/>
        <source>Blurring for translucent windows</source>
        <translation>Yarımşəffaf pəncərələr üçün bulanıqlıq</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1164"/>
        <source>A 200ms fading animation when the state of
some widgets is changed, mostly by the mouse.</source>
        <translation>200 ms-lik sönmə animasiyası ilə bəzi vidjetlərin 
vəziyyətinin əksər hallarda siçan ilə dəyişdirilməsi.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1168"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;A 200ms fading animation when the state of some widgets is changed, mostly by the mouse.&lt;/p&gt;&lt;p&gt;The CPU usage is negligible because often only one widget is animated. The resulting visual effect depends on the active theme.&lt;/p&gt;&lt;p&gt;These widgets are supported: buttons (including radio buttons and check boxes), combo boxes, spin boxes, slider handles, line-edits and scroll views.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;200 msan-lik sönmə effekti ilə bəzi vidjetlərin əksər hallarda siçan ilə vəziyyətinin dəyişdirilməsi.&lt;/p&gt;&lt;p&gt;CPU istifaəsi əhəmiyyətsiz dərəcədə olur, çünki əsasən yalnız bir vidjet animasiyalı olur. Ortaya çıxan visual effekt aktiv mövzudan asılıdır.&lt;/p&gt;&lt;p&gt;Bu vidjetlər dəstəklənir: düymələr (dəyişdirici düymələr və işarələnəbilən xanalar), siyahı və döndərmə qutuları sürüşdürmə tutacağı, düzəliş sətirləri, sürüşdürmə çubuqları&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1171"/>
        <source>Animation for state change under mouse</source>
        <translation>Kursor altında vəziyyət dəyişmə animasiyası</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1178"/>
        <source>Check this to remove all window/dialog tiling patterns!
Uncheck it if you want those patterns back!</source>
        <translation>Bütün pəncərələrin/dialoqların yerləşdirmə şablonları ləğv etmək üçün işarələyin!
Bu şəkildə yerləşməni bərpa etmək istəsəniz xanadakı işarəni ləğv edin!</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1182"/>
        <source>Remove window/dialog tiling patterns</source>
        <translation>Pəncərələrin yerləşdirmə şablonlarını ləğv etmək</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1189"/>
        <source>Use the same colors and shapes with active and inactive
windows if this theme distinguishes between them?</source>
        <translation>Əgər hazırkı mövzu rəngləri və formaları bir-birindən
fərqləndirirsə eyni rəng və formadan istifadə edilsin?</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1193"/>
        <source>Ignore inactive state</source>
        <translation>Qeyri-aktiv vəziyyəti nəzərə almamaq</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1207"/>
        <source>Transient scrollbars</source>
        <translation>Müvəqqəti sürüşdürmə çubuqları</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1229"/>
        <source>Sizes &amp;&amp; Delays</source>
        <translation>Ölçülər və gecikmələr</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1235"/>
        <source>Sizes</source>
        <translation>Ölçülər</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1250"/>
        <source>Small icon:</source>
        <translation>Kiçik nişan:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1288"/>
        <source>Large icon:</source>
        <translation>Böyük nişan:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1322"/>
        <source>Button icon:</source>
        <translation>Düymə nişanı:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1354"/>
        <source>Toolbar icon:</source>
        <translation>Alətlər paneli nişanı:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1368"/>
        <source>Font size</source>
        <translation>Yazı ölçüsü</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1384"/>
        <location filename="../../kvantummanager.ui" line="1395"/>
        <source>The default value is 3 px but
some apps set it themeselves.</source>
        <translation>İlkin ölçü 3 pikseldir, lakin ölçünü
bəzi tətbiqlər özləri təyin edir.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1388"/>
        <source>Layout spacing:</source>
        <translation>Yerləşmə aralığı:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1412"/>
        <location filename="../../kvantummanager.ui" line="1422"/>
        <source>The default value is 6 px but some apps set it themeselves.</source>
        <translation>ilkin dəyər 6 pikseldir, lakin bunu bəzi tətbiqlər özləri təyin edir.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1415"/>
        <source>Layout margin:</source>
        <translation>Kənarların sahəsi:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1438"/>
        <location filename="../../kvantummanager.ui" line="1450"/>
        <source>The horizontal overlap between a submenu and its parent.

0 by default.</source>
        <translation>Menyu ilə alt menyunun üfüqi üst-üstə düşməsi.

İlkin dəyər 0-dır.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1443"/>
        <source>Submenu overlap: </source>
        <translation>Alt menyunun örtməsi: </translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1468"/>
        <location filename="../../kvantummanager.ui" line="1479"/>
        <source>The width of horizontal spin buttons.
(Has no effect when spin indicators are vertical.)</source>
        <translation>Üfüqi döndərmə düymələrinin eni.
(Üfüqi döndərmə göstəricisinə aid deyil.)</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1472"/>
        <source>Spin button width: </source>
        <translation>Döndərmə düyməsinin eni: </translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1846"/>
        <location filename="../../kvantummanager.ui" line="1856"/>
        <source>How to activate view items?</source>
        <translation>Baxış elementlərini necə aktiv edək?</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1849"/>
        <source>Click behavior:</source>
        <translation>Klikləmə davranışı:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1969"/>
        <source>Draw tree branch lines?

By default, tree branches have indicators but no line.</source>
        <translation>Ağac budağı xətləri çəkilsin?

İlkin olaraq ağac budaqları üçün
gıstəricilər olur, xəttlər olmur.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1948"/>
        <source>Dialog button layout:</source>
        <translation>Dialoq düyməsi düzülüşü:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1958"/>
        <source>They may look like dotted rectangles
on focused buttons and other widgets.</source>
        <translation>Fokuslanmış düymələrdə və digər vidjetlərdə 
onlar nöqtəli dördbucaq kimi görünə bilər.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1962"/>
        <source>Remove focus rectangles</source>
        <translation>Fokus dördbucağını ləğv etmək</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2162"/>
        <source>Use the active theme for all apps!

This Needs saving to take effect.</source>
        <translation>Bütün tətbiqlər üçün aktiv mövzu istifadə edin.

Effektin qüvvəyə minməsi üçün onu saxlamaq lazımdır.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="183"/>
        <source>Remove the selected theme
from all user installation paths.

The root installation will still be
available if present; this button
only removes user themes.</source>
        <translation>Seçilən mövzunu bütün istifadəçi 
quraşdırma yollarından silin.

Kök quraşdırma hələ də istifadə 
oluna bilər, bu düymə yalnız
istifadəçi mövzusularını silir.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="391"/>
        <source>Merge Dolphin&apos;s view with its surroundings?

By default, it has the base background.</source>
        <translation>Dolphin-in görünüşü ətrafı ilə birləşdirilsin?

İlkin olaraq əsas təməl fon quraşdırılb.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="419"/>
        <source>No bold font for default push buttons?

Such push buttons have bold text by default.</source>
        <translation>İlkin basma düymələrində qalın yazı olmasın?

İlkin olaraq belə düymələrdə yazı qalın olur.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="458"/>
        <source>No icon for push buttons that have text?

By default, most push buttons have icon.

If this is disabled, see:
Miscellaneous → Respect current DE if possible</source>
        <translation>Mətn olan basma düymələri üçün nişan yoxdur?

İlkin halda bir çox basma düymələrində nişan olur.

Əgər bu söndürülbsə, baxın:
Müxtəlif → mümkünsə cari iş masasına uyğunlaşdırmaq</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="487"/>
        <source>No icon for menu-items?

By default, some of them may have icon.

If this is disabled, see:
Miscellaneous → Respect current DE if possible</source>
        <translation>Menyu elementləri üçün nişan yoxdur?

İlkin olaraq bunlardan bəzilərində nişan olur.

Əgər bu söndürülbsə, baxın:
Müxtəlif → mümkünsə cari iş masasına uyğunlaşdırmaq</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="502"/>
        <source>Blur the regions behind windows that are made
translucent by their apps explicitly if possible.

This needs the KDE blur effect.

Konsole, QTerminal and LXQt panel are some examples.</source>
        <translation>Mümkünsə tətbiqləri tərəfindən yarımşəffaf edilən
pəncərələrin arxasındakı bölgələri bulanıqlaşdırmaq.

Bunun üçün KDE bulanıqlıq effekti lazımdır.

Konsole, QTerminal və LXQt paneli bəzi nümunələrdir.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="517"/>
        <source>Only the top toolbar should be styled?

By default, all toolbars are styled,
whether they are on the top or at any
other position.</source>
        <translation>Yalnız yuxarı alətlər paneli üslublaşdırılsın?

Standart olaraq bütün alət panelləri,
istər yuxarıda, istərsə də digər
mövqelərdə olsun, üslublaşdırılır.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="644"/>
        <location filename="../../kvantummanager.ui" line="658"/>
        <source>The highlight color is used for tinting.

This is mostly relevant with monochrome icons.

Hard-coded icons/styles may not respect this key.</source>
        <translation>Vurğulama rəngi rənglənmə üçün istifadə olunur.

Bu daha çox təkrəngli nişanlar ilə uyğundur.

Ciddi kodlanmış nişanlar/üslublar bu açar ilə
uyğunlaşmaya bilər.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="606"/>
        <source>Some apps may not respect dark themes.
Kvantum can try to correct their behavior
as far as possible.</source>
        <translation>Bəzi tətbiqlər tünd mövzuya uyğunlaşmaya
bilər. Kvantum mümkün olduqda onların 
davranışlarını düzəltməyə cəhd edə bilər.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1139"/>
        <source>Needs KDE blur effect, a graphic card
that supports it, and a translucent
window SVG background in the theme.</source>
        <translation>KDE bulanıqlıq effekti, onu dəstəkləyən
qrafik kartı və mövzuda yarımşəffaf 
pəncərə SVG arxa fonu lazımdır.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1217"/>
        <source>Should transient scrollbars have
semi-transparent grooves when needed?</source>
        <translation>Müvəqqəti sürüşdürmə zolaqlarında
ehtiyac olduqda yarı-şəffaf kanallar olsun?</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1221"/>
        <source>Transient scrollbar grooves when needed</source>
        <translation>Lazım olduqda müvəqqəti sürüşdürmə çubuğu kanalları</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1241"/>
        <location filename="../../kvantummanager.ui" line="1257"/>
        <source>Affects menu-items and headers.

The default value is 16 px but
some apps may set it themselves.

If this is disabled, see:
Miscellaneous → Respect current DE if possible</source>
        <translation>Menyu elementləri və başlıqlarına tətbiq edilir.

İlkin olaraq dəyər 16 pikseldir, lakin bəzi
tətbiqlər dəyərləri özü təyin edə bilər.

Əgər bu spndürülübsə, baxın:
Müxtəlif → Mümkünsə cari iş masasına uyğunlaşdrımaq</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1279"/>
        <location filename="../../kvantummanager.ui" line="1295"/>
        <source>Affects icon views.

The default value is 32 px but
some apps set it themselves.

If this is disabled, see:
Miscellaneous → Respect current DE if possible</source>
        <translation>Nişan görünüşlərinə tətbiq edilir.

İlkin dəyər 32 pikseldir, lakin bəzi
tətbiqlər özü dəyər təyin edə bilər.

Əgər bu söndürülübsə, baxın:
Müxtəlif → Mümkünsə cari işa masasına uyğunlaşdırmaq</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1317"/>
        <location filename="../../kvantummanager.ui" line="1329"/>
        <source>Affects buttons, tab-bars and list-views.

The default value is 16 px.</source>
        <translation>Düymələrə, vərəqlərə və siyahılara tətbiq edilir.

İlkin dəyər 16 pikseldir.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1347"/>
        <location filename="../../kvantummanager.ui" line="1361"/>
        <source>Affects toolbars.

The default value is 22 px but
some apps set it themselves.
KDE apps get it from KDE setting.</source>
        <translation>Alətlər panellərinə tətbiq edilir.

İlkin dəyər 22 pikseldir, lakin bəzi
tətbiqlər özü dəyər təyin edə bilər.
KDE tətbiqləri onları KDE ayarından alır.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1499"/>
        <location filename="../../kvantummanager.ui" line="1512"/>
        <source>The minimum length of scrollbars.</source>
        <translation>Sürüşdürmə çubuqlarının minimum eni.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1502"/>
        <location filename="../../kvantummanager.ui" line="1515"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The minimum height of vertical scrollbars and the minimum width of horizontal scrollbars.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Şaquli sürüşdürmə çubuğunun minimum hündürlüyü və üfüqi sürüşdürmə çubuğunun minimum eni.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1505"/>
        <source>Minimum scrollbar length: </source>
        <translation>Minimum şürüşdürmə çubuğu uzunluğu: </translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1550"/>
        <source>Delays</source>
        <translation>Gecikmələr</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1556"/>
        <location filename="../../kvantummanager.ui" line="1584"/>
        <source>The delay, in milliseconds, before a tooltip is shown.

Zero means tooltips are shown instantly.

-1 means the default Qt behavior.</source>
        <translation>Alət ipucları göstərilmədən öncəki millisaniyə ilə gecikmə.

Sıfır dəyəri ipuclarının dərhal göstəriləcəyini bildirir.

-1 ilkin Qt dəyəri deməkdir.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1832"/>
        <source>Scrollbars have add-line and sub-line arrows by default.

Checking this box removes arrows as far as possible.

If disabled, see Compositing &amp; General Look → Transient scrollbars!</source>
        <translation>İlkin olaraq sürüşdürmə çubuqlarında oxlar olur.

Bu xananı işarələmək mümkün olduqda oxları silir.

Əgər söndürülübsə, Birləşmələr və əsas görünüş → Müvəqqəti 
sürüşdürmə çubuqlar bölməsinə baxın!</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1698"/>
        <source>By default, drop rectangles for movable
toolbars and dock widgets are hollow.

This option fills drop rectangles with
the highlight color.</source>
        <translation>İlkin olaraq, köçürülə bilən alət panelləri 
və dock paneli vidcetləri üçün yerləşdirmə 
çərçivələri boş (içi doldurulmamış) olur.

Bu parametri aktiv etmək yerləşdirmə 
çərçivələrini vurğulama rəngi ilə doldurur.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1753"/>
        <source>If checked, the menubar and toolbar will be drawn as a whole by
the toolbar SVG element when they are adjacent to each another.</source>
        <translation>Bu xana işarələnərsə menyu çubuğu və alətlər paneli bir-birinə
bitişik olduqda alətlər çubuğu SVG nişanları tərəfindən bötöv
şəkildə göstərilir.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1981"/>
        <location filename="../../kvantummanager.ui" line="1995"/>
        <source>Drag windows from their menubars, primary toolbars
or anywhere possible (and not only from their title bars)?

If this is disabled, see:
Miscellaneous → Respect current DE if possible</source>
        <translation>Pəncərələri yalnız başlıq çubuqlarından deyil onların menyu 
çubuqlarından, birinci alətlər panelindən və ya mümkün olduqda
istənilən yerdən tutub sürüşdürmək mümkün olsun?

Əgər bu söndürülübsə, baxın:
Müxtəlif → Mümkünsə hazırkı iş masası mühitinə uyğunlaşdırmaq</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1892"/>
        <location filename="../../kvantummanager.ui" line="1911"/>
        <source>Will have effect only if style
is not set by the app in its code.

Default is &quot;Follow Style&quot;.</source>
        <translation>Üslub yalnız tətbiq tərəfindən təyin 
edilmədikdə tətbiq olunacaq.

İlkin variant: &quot;Üslubu izləmək&quot;.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1684"/>
        <source>By default, spin indicators are drawn as
two buttons with arrows or plus/minus signs.

Checking this integrates the spin indicators
into the spin line-edit..</source>
        <translation>İlkin olaraq döndərmə göstəricisi iki oxdan
ibarət düymə və ya mənfi/müsbət işarələri
olan düymələr kimi göstərilir.

Bu xananı işarələmək, döndərmə göstəricisini
xətti döndərmə cizgisinə inteqrasiya edir.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1712"/>
        <source>By default, spin indicators are drawn on adjacent buttons.

Checking this puts the spin-up indicator above the
spin-down one inside the spin line-edit.</source>
        <translation>İlkin olaraq döndərmə göstəricisi bitiş düymələrdə göstərilir.

Bu xananı işarələmək, döndərməli daxiletmə sahəsində (spin line-edit)
yuxarı döndərmə göstəricisini aşağı döndərmə göstəricisinin üzərində
yerləşdirir.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1764"/>
        <source>Draw combo popups as menu popups (i.e. like in Gtk)?

By default, combo popups do not cover the combo box.</source>
        <translation>Açılan siyahı pəncərələri açılan menyular 
(məs., Gtk-dəki kimi) kimi görünsün?

İlkin olaraq, açılan siyahı pəncərələri açılan siyahı 
sahəsini ötrmür.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1811"/>
        <source>In Kvantum, tabs are centered by default.</source>
        <translation>İlkin variantda Kvantum-da vərəqlər mərkəzdə yerləşir.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1563"/>
        <source>Tooltip delay:</source>
        <translation>İpucları gecikməsi:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="991"/>
        <location filename="../../kvantummanager.ui" line="1021"/>
        <source>A comma-separated list of executables,
whose windows should not be translucent.

(Some apps, like video players, may have
problems with translucency!)</source>
        <translation>Pəncərələri şəffaf olmayan icra fayllarının 
vergüllə ayrılmış siyahısı.

(Video oynadıcılar kimi bəzi tətbiqlərin
yarımşəffaf olması problem yarada bilər)</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1200"/>
        <source>Make scrollbars transient!

Transient scrollbars appear on top of
their scroll views only when needed.
They usually take no extra space.</source>
        <translation>Sürüşdürmə çubuqlarını müvəqqəti edin!

Müvəqqəti sürüşdürmə çubuqları yalnız lazım
olduqda öz sürüşdürmə sahəsi üzərində 
görünəcək. Bu adətən çox yer tutmur.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1570"/>
        <location filename="../../kvantummanager.ui" line="1607"/>
        <source>The delay, in milliseconds, to wait before opening a submenu.
250 by default.

-1 means no popup (opening by clicking),
while 0 means no delay.</source>
        <translation>Alt menyu açılana qədərki müddətdə millisaniyələrlə gecikmə.
İlkin variant 250-dir.

-1 dəyəri (klikləmə ilə) açılan pəncərə olmadığını, 0 dəyəri
isə gecikmə olmadığını göstərir.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1577"/>
        <source>Submenu delay: </source>
        <translation>Alt menyu gecikməsi: </translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1591"/>
        <location filename="../../kvantummanager.ui" line="1614"/>
        <source> ms</source>
        <translation> msan</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1647"/>
        <source>Miscellaneous</source>
        <translation>Müxtəlif</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1839"/>
        <source>No arrows for scrollbars</source>
        <translation>Sürüşdürmə çubuğunda oxlar olmasın</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1934"/>
        <source>Draw scrollbars inside view frames?

By default, scrollbars are drawn outide view frames.

If disabled, see Compositing &amp; General Look → Transient scrollbars!</source>
        <translation>Sürüşdürmə çubuğu baxış çərçivəsində göstərilsin?

İlkin variantda sürüşdürmə çubuğu çərçivənin kənarında
göstərilir.

Əgər xana işarələnməyibsə, Birləşdirici və Əsas görünüş → 
Müvəqqəti sürüşdürmə çubuqları bölməsinə baxın!</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1941"/>
        <source>Scrollbars inside frames</source>
        <translation>Sürüşdürmə panelləri çərçivə daxilində</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1974"/>
        <source>Tree branch lines</source>
        <translation>Budaqlanma xəttləri</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1670"/>
        <source>By default, the label is on the frame
and the frame is cut to contain it.

Checking this puts the label right above
the frame, so that the frame isn&apos;t cut.</source>
        <translation>İlkin variantda etket çərçivə daxilində olur
və çərçivənin ölçüsü tərkibinə uyğunlaşır.

Bu xananı işarələmək etiketi birbaşa şərçivənin
üzərində yerləşdirir, beləliklə çərçivə bütöv qalır.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1677"/>
        <source>Group-box label above frame</source>
        <translation>Qrupun etiket çərçivə üzərində</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1705"/>
        <source>Fill rubber-band rectangles</source>
        <translation>Elastik çərçivəni doldurmaq</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1725"/>
        <source>Mouse tracking is enabled
for menubars by default.</source>
        <translation>İlkin variantda siçan izləməsi menyu 
panelləri üçün aktiv edilib.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1729"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Mouse tracking is enabled for menubars by default, i.e., after a menubar item is clicked and its menu is shown, the menus of the other menubar items will be shown if the cursor is put on them without clicking.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Siçan izləmə standart olaraq menyu panelləri üçün aktivləşdirilir, yəni menyu çubuğunun elementi kliklədikdən və onun menyusu göstərildikdən sonra kursor klikləmədən onların üzərinə dayandırılarsa, digər menyu elementlərinin menyuları görünəcək.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1732"/>
        <source>Mouse tracking for menubars</source>
        <translation>Menyu panelləri üçün siçan izləməsi</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1757"/>
        <source>Merge menubar with toolbar</source>
        <translation>Menyu panelini alətlər paneli ilə birləşdirin</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1776"/>
        <source>If checked, toolbar buttons will be drawn grouped and raised
between toolbar separators.</source>
        <translation>Bu xana işarələnərsə alətlər paneli düymələri 
alətlər paneli ayırıcıları arasında yerləşdiriləcək.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1780"/>
        <source>Group toolbar buttons</source>
        <translation>Alətlər paneli düymələrini qruplaşdırın</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1988"/>
        <source>Drag from:</source>
        <translation>Buradan sürükləyin:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1898"/>
        <source>Toolbutton style:</source>
        <translation>Alət düyməsi tərzi:</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1801"/>
        <source>If unchecked, shortcuts will not be underlined at all.</source>
        <translation>Əgər işarələnməzsə qısa yol düymələri 
altından xətt çəkilməyəcək.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1804"/>
        <source>Underline shortcuts with Alt</source>
        <translation>Alt ilə qısayol düymələri altından xətt çəkmək</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1691"/>
        <source>Inline spin indicators</source>
        <translation>Sətirdaxili döndərmə göstəricisi</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1739"/>
        <source>Draw the whole editable combo-box as a
line-edit with arrow (and icon, if it exists)?</source>
        <translation>Bütöv düzəliş ediləbilən siyahı sahəsi oxları 
olan daxiletmə sətri (və əgər varsa nişan)
kimi göstərilsin?</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1743"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Draw the whole editable combo-box as a line-edit with arrow (and icon, if it exists)?&lt;/p&gt;&lt;p&gt;By default, a combo-box consists of a line-edit, a button with arrow on one side and another button with icon on the other side.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bütöv düzəliş ediləbilən siyahı sahəsi oxları olan daxiletmə sətri (və əgər varsa nişan) kimi göstərilsin?&lt;/p&gt;&lt;p&gt;İlkin variant olaraq, kombinasiya qutusu sətir redaktəsindən, bir tərəfində ox olan düymədən və digər tərəfində işarəsi olan digər düymədən ibarətdir..&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1746"/>
        <source>Editable combo as line-edit</source>
        <translation>Düzəliş ediləbilən sahə sətir kimi</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1718"/>
        <source>Vertical spin indicators</source>
        <translation>Şaquli döndərmə göstəricisi</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1653"/>
        <source>When this is enabled and checked, Kvantum will try to
respect some settings of the current desktop environment.

This checkbox may disable some options.
Uncheck it if you want to use those options!</source>
        <translation>Bu aktiv edilərsə, Kvantum bəzi ayarları cari iş masası
mühitinə uyğunlaşdırmağa çalışacaq.

Bu xananın işarələnməsi bəzi parametrləri söndürə bilər.
Bu parametrləri istifadə etmək istəsəniz işarəni qaldırın!</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1663"/>
        <source>Respect current DE if possible</source>
        <translation>Hazırkı iş masası mühitinə uyğun</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1769"/>
        <source>Combo popup as menu</source>
        <translation>Açılan siyahı qutusu menyu şəklində</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1814"/>
        <source>Left aligned tabs</source>
        <translation>Sola düzülmüş vərəqlər</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1821"/>
        <source>Inactive tabs are joined together by default,
i.e., there is no border between them.</source>
        <translation>İlkin variantda aktiv olmayan vərəqlər birləşik olur,
yəni, onlar arasında heç bir sərhəd yoxdur.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1825"/>
        <source>Join inactive tabs</source>
        <translation>Aktiv olmayan vərəqləri birləşdirmək</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2012"/>
        <source>Scrollable menus</source>
        <translation>Sürüşdürüləbilən menyu</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1660"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;When this is enabled and checked, Kvantum will try to respect some settings of the current desktop environment if it is KDE, Unity, Gnome or Pantheon.&lt;/p&gt;&lt;p&gt;Under KDE, it makes Kvantum read KDE settings for small and large icon sizes and also single or double clicking.&lt;/p&gt;&lt;p&gt;Under Unity, Gnome and Pantheon, it removes icons from menus and push-buttons (even if the corresponding dconf keys are changed) and disables window translucency.&lt;/p&gt;&lt;p&gt;This checkbox may disable some options. Uncheck it if you want to use those options!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bu aktivləşdirildikdə və işarələniksə, Kvantum, əgər KDE, Unity, Gnome və ya Pantheondursa, cari iş masası mühitinin bəzi parametrlərinə uyğunlaşmağa çalışacaq..&lt;/p&gt;&lt;p&gt;Bu, KDE mühitində Kvantum-a kiçik və böyük nişan ölçüləri üçün KDE parametrlərini, tək və ya cüt toxunuşla oxumağa imkan verir.&lt;/p&gt;&lt;p&gt;Unity, Gnome və Pantheon mühitində o, menyulardan və düymələrdən nişanları silir (hətta müvafiq dconf düymələri dəyişdirilsə belə) və pəncərə şəffaflığını söndürür..&lt;/p&gt;&lt;p&gt;Bu işarələmə xana bəzi parametrləri deaktiv edə bilər. Bu parametrlərdən istifadə etmək istəyirsinizsə, işarəni silin!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="848"/>
        <source>This needs the KDE contrast effect and is applied
only to translucent windows that support the blur
effect (but the KDE blur effect can be disabled).

A value of 1.00 means no change.</source>
        <translation>KDE kontrast effekti aktiv edilməlidir və yalnız
bulanıqlıq effektini dəstəkləyən yarımşəffaf pəncərələrə
tətbiq edilir. (KDE bulanıqlıq effektini söndürmək olar).

1.00 dəyəri heç bir dəyişiklik olmadığını göstərir.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1050"/>
        <location filename="../../kvantummanager.ui" line="1083"/>
        <source>This will reduce the window opacity
if window translucency is enabled.

A translucent SVG background is NOT
needed for this key to work.

A negative value means that only the
opacity of inactive windows is reduced.</source>
        <translation>Pəncərə yarımşəffaflığının aktiv edilməsi
pəncərənin qeyri-şəffaflığını azaldır.

Bu parametrin işləməsi üçün SVG fonu
tələb olunmur.

Mənfi dəyər, yalnız aktiv olmayan pəncərələrin
qeyri-şəffaflığının azaldılacağını göstərir.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1787"/>
        <source>When drawing combo popups as menus,
there will be a checkbox next to each entry
(although Kvantum draws it as a radio button).

This option will hide these.</source>
        <translation>Açılan siyahı qutusu menyu kimi göstərildiyi 
zaman hər bir girişin yanında işarələmə xanası
yerləşəcək (baxmayaraq ki, Kvantum bunu
dəyişdirici düymə kimi göstərəcək).

Bu parametr bu sahələri gizlədəcək.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="1794"/>
        <source>Non-checkable combo menu</source>
        <translation>İşarələnə bilməyən siyahı menyusu</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2006"/>
        <source>Should big menus be scrollable and have
scroll arrows on their top and/or bottom?

By default, big menus are scrollable.</source>
        <translation>Böyük menyular sürüşdürülə bilən, yuxarısında
və aşağısında sürüşdürmə oxlarına malik olmalıdır?

İlkin variantda böyük menyular sürüşdürülə bilən olur.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2019"/>
        <source>Warning: This can be quite confusing at first.

If you have enabled it, you could temporarily disable it
for a button that can be dragged and dropped by pressing
the Ctrl key before pressing the button.</source>
        <translation>Xəbərdarlıq: Bu ilk baxışda olduqca çaşdırıcı ola bilər.

Əgər aktiv etsəniz, bunu, düyməni basmazdan 
əvvəl Ctrl düyməsini basaraq yeri dəyişdiriləbilən 
düymə üçün söndürə bilərsiniz.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2026"/>
        <source>Allow dragging from buttons</source>
        <translation>Düymədən sürükləməyə icazə vermək</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2049"/>
        <source>Application Themes</source>
        <translation>Tətbiq mövzuları</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2055"/>
        <source>&lt;center&gt;Here you could assign themes to specific applications.&lt;/center&gt;&lt;br&gt;&lt;center&gt;For each theme, you could add a comma-separated list of executables whose applications should use that theme instead of the active theme. After doing so for all of your chosen themes, save the result by clicking on the &lt;i&gt;Save&lt;/i&gt; button!&lt;/center&gt;</source>
        <translation>&lt;center&gt;Burada tətbiqlər üçün ayrıca görünüş tərzi (mövzu) təyin edə bilərsiniz.&lt;/center&gt;&lt;br&gt;&lt;center&gt;Hər görünüş tərzi üçün, tətbiqləri aktiv mövzu əvəzinə həmin mövzudan istifadə etməli olan icra fayllarının vergüllə ayrılmış siyahısını əlavə edə bilərsiniz. Seçdiyiniz bütün mövzular üçün bunu etdikdən sonra, &lt;i&gt;Saxla!&lt;/i&gt; düyməsinə klikləməklə nəticəni yadda saxlayın!&lt;/center&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2090"/>
        <source>Installed Theme</source>
        <translation>Quraşdırılmış mövzular</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2106"/>
        <source>Application(s)</source>
        <translation>Tətbiq(lər)</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2135"/>
        <source>Each executable name can be either a
simple string or a regular expression.</source>
        <translation>Hər bir icra faylının adı sadə sətir 
və ya müntəzəm ifadə ola bilər.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2139"/>
        <source>app1,app2,app3</source>
        <translation>tətb1,tətb2,tətb3</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2167"/>
        <source>Remove List</source>
        <translation>Siyahını silin</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2174"/>
        <source>Save the current list of apps</source>
        <translation>Tətbiqlərin cari siyahısını saxlayın</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2177"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Save the current list of applications with their corresponding themes!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Uyğun mövzuları ilə tətbiqlərin cari siyahısını saxlamaq!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2204"/>
        <location filename="../../kvantummanager.ui" line="2210"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2207"/>
        <source>Quit</source>
        <translation>Çıxın</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2220"/>
        <source>Preview the active theme
or update its preview.</source>
        <translation>Aktiv mövzuya öncədən baxın və ya 
ön baxış miniatürlərini yeniləyin.</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2224"/>
        <source>Preview</source>
        <translation>Öncədən baxış</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2231"/>
        <source>About</source>
        <translation>Haqqında</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2254"/>
        <source>What&apos;s This?</source>
        <translation>Bu nədir?</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2257"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Click on this button and then click on a GUI element that has &amp;quot;What&apos;s This&amp;quot; tooltip  to get information about what it does.&lt;/p&gt;&lt;p&gt;There are also ordinary tooltips but this kind of tooltip will not disappear until you click somewhere.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bu düymənin fəaliyyəti haqqında məlumat almaq üçün bu düyməyə, sonra  &amp;quot;Bu nədir?&amp;quot; ipucu olan qrafik interfeys elementin üzərinə klikləyin.&lt;/p&gt;&lt;p&gt;Adi alət ipuclarından fərqli olaraq bu növ ipucları yalnız hər hansı bir boş yerə vurduqda itəcəkdir.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../kvantummanager.ui" line="2260"/>
        <source>Help</source>
        <translation>Kömək</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="328"/>
        <source>Open Kvantum Theme Folder...</source>
        <translation>Kvantum mövzusu qovluğunu açın...</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="191"/>
        <location filename="../../KvantumManager.cpp" line="202"/>
        <location filename="../../KvantumManager.cpp" line="515"/>
        <location filename="../../KvantumManager.cpp" line="532"/>
        <location filename="../../KvantumManager.cpp" line="548"/>
        <location filename="../../KvantumManager.cpp" line="559"/>
        <location filename="../../KvantumManager.cpp" line="570"/>
        <location filename="../../KvantumManager.cpp" line="597"/>
        <location filename="../../KvantumManager.cpp" line="612"/>
        <location filename="../../KvantumManager.cpp" line="659"/>
        <location filename="../../KvantumManager.cpp" line="675"/>
        <source>Kvantum</source>
        <translation>Kvantum</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="599"/>
        <source>First you have to delete its modified version!</source>
        <translation>Öncə onun dəyişiklik edilmiş versiyasını silin!</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="623"/>
        <location filename="../../KvantumManager.cpp" line="777"/>
        <location filename="../../KvantumManager.cpp" line="2819"/>
        <source>Confirmation</source>
        <translation>Təsdiq edin</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="738"/>
        <source>%1 installed.</source>
        <translation>$1 quraşdırıldı.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="908"/>
        <source>%1 deleted.</source>
        <translation>$1 silindi.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="1009"/>
        <source>Theme changed to %1.</source>
        <translation>Mövzu $1 olaraq dəyişdirildi.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="516"/>
        <source>You have no permission to write here:</source>
        <translation>Bura yazmaq icazəniz yoxdur:</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="105"/>
        <location filename="../../KvantumManager.cpp" line="109"/>
        <location filename="../../KvantumManager.cpp" line="115"/>
        <source>Follow Style</source>
        <translation>Üsluba əsasən</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="106"/>
        <source>Single Click</source>
        <translation>Tək klik</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="107"/>
        <source>Double Click</source>
        <translation>Cüt klik</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="110"/>
        <source>Icon Only</source>
        <translation>Yalnız nişan</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="111"/>
        <source>Text Only</source>
        <translation>Yalnız mətn</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="112"/>
        <source>Text Beside Icon</source>
        <translation>Mətn nişan yanında</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="113"/>
        <source>Text Under Icon</source>
        <translation>Mətn nişanın üstündə</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="116"/>
        <source>KDE Layout</source>
        <translation>KDE düzülüşü</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="117"/>
        <source>Gnome Layout</source>
        <translation>Gnome düzülüşü</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="118"/>
        <source>Mac Layout</source>
        <translation>Mac düzülüşü</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="119"/>
        <source>Windows Layout</source>
        <translation>Windows düzülüşü</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="120"/>
        <source>Android Layout</source>
        <translation>Android düzülüşü</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="122"/>
        <source>Titlebar</source>
        <translation>Başlıq paneli</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="123"/>
        <source>Menubar</source>
        <translation>Menyu çubuğu</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="124"/>
        <source>Menubar and primary toolbar</source>
        <translation>Menyu çubuğu və əsas alətlər paneli</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="125"/>
        <source>Anywhere possible</source>
        <translation>Mümkün olan hər yerdə</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="518"/>
        <source>Please fix that first!</source>
        <translation>Öncə bu problemi həll edin!</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="530"/>
        <source>This file cannot be removed:</source>
        <translation>Bu fayl silinə bilməz:</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="549"/>
        <location filename="../../KvantumManager.cpp" line="560"/>
        <source>This is not an installable Kvantum theme!</source>
        <translation>Bu quraşdırılabilən Kvantum mövzusu deyil!</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="550"/>
        <source>The name of an installable themes should not be &quot;Default&quot;.</source>
        <translation>Quraşdırılabilən mövzuların adı &quot;Default&quot; ola bilməz.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="551"/>
        <location filename="../../KvantumManager.cpp" line="562"/>
        <location filename="../../KvantumManager.cpp" line="572"/>
        <source>Please select another directory!</source>
        <translation>Başqa qovluq seçin!</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="561"/>
        <source>Installable themes should not have # in their names.</source>
        <translation>Quraşdırılabilən mövzunun adında # ola bilməz.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="571"/>
        <source>This is not a Kvantum theme folder!</source>
        <translation>Bu Kvantum mövzu qovluğu deyil!</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="598"/>
        <source>The theme already exists in modified form.</source>
        <translation>Mövzu artıq dəyişdirilmiş formada mövcuddur.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="613"/>
        <source>You have selected an installed theme folder.</source>
        <translation>Quraşdırılmış mövzu qovluğu artıq seçilib.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="614"/>
        <source>Please choose another directory!</source>
        <translation>Başqa qovluq seçin!</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="624"/>
        <source>The theme already exists.</source>
        <translation>Mövzu artıq mövcuddur.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="625"/>
        <source>Do you want to overwrite it?</source>
        <translation>Onu əvəzləmək istəyirsiniz?</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="660"/>
        <source>This theme is also installed as root in:</source>
        <translation>Bu mövzu artıq bu qovluqda quraşdırılıb:</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="662"/>
        <source>The user installation will take priority.</source>
        <translation>İstifadəçinin quraşdırdığı üstünlüyə malik olacaq.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="676"/>
        <source>This theme is also installed as user in:</source>
        <translation>Həmçinin bu, istifadəçi mövzusu kimi burada quraşdırılıb:</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="678"/>
        <source>This installation will take priority.</source>
        <translation>Bu quraşdırma üstünlüyə malik olacaq.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="778"/>
        <source>Do you really want to delete &lt;i&gt;%1&lt;/i&gt;?</source>
        <translation>&lt;i&gt;%1&lt;/i&gt; həqiqətən silinsin?</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="781"/>
        <source>It could not be restored unless you have a copy of it.</source>
        <translation>Bir surəti olmadıqca bərpa edilə bilməz.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="1435"/>
        <location filename="../../KvantumManager.cpp" line="1455"/>
        <source>These are the settings that can be safely changed.&lt;br&gt;For the others, click &lt;i&gt;Save&lt;/i&gt; and then edit this file:</source>
        <translation>Bunlar təhlükəsiz dəyişdirilə bilən ayarlardır.&lt;br&gt;Digər parametrlər üçün &lt;i&gt;Saxlayın&lt;/i&gt; seçin və bu fayla düzəliş edin:</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="1451"/>
        <location filename="../../KvantumManager.cpp" line="2727"/>
        <source>These are the settings that can be safely changed.&lt;br&gt;For the others, edit this file:</source>
        <translation>Bunlar təhlükəsiz dəyiçdirilə bilən ayarlardır. &lt;br&gt;Digər parametrlər üçün bu faylı dəyişin:</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="1853"/>
        <source>No description</source>
        <translation>Açıqlaması yoxdur</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="2306"/>
        <source>A copy of the root config is created.</source>
        <translation>Kök tənzimləmənin surəti yaradıldı.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="2317"/>
        <source>A copy was already created.</source>
        <translation>Surəti artıq yaradılıb.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="2713"/>
        <source>Configuration saved.</source>
        <translation>Tənzimləmə saxlanıldı.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="2820"/>
        <source>Do you want to revert to the default (root) settings of this theme?</source>
        <translation>Bu mövzunu ilkin (kök) ayarlarına qaytarmaq istəyirsiniz?</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="2823"/>
        <source>You will lose the changes you might have made.</source>
        <translation>Bütün edilmiş dəyişikliklər itiriləcəkdir.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="2858"/>
        <source>Restored the root default settings of %1</source>
        <translation>$1 mövzusunun kök parametrlərinə bərpa edildi</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="2859"/>
        <source>the default theme</source>
        <translation>ilkin mövzu</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="3012"/>
        <location filename="../../KvantumManager.cpp" line="3013"/>
        <source>About Kvantum Manager</source>
        <translation>Kvantum meneceri haqqında</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="3012"/>
        <source>Translators</source>
        <translation>Tərcüməçilər</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="3010"/>
        <source>A tool for installing, selecting&lt;br&gt;and configuring &lt;a href=&apos;https://github.com/tsujan/Kvantum&apos;&gt;Kvantum&lt;/a&gt; themes</source>
        <translation>&lt;a href=&apos;https://github.com/tsujan/Kvantum&apos;&gt;Kvantum&lt;/a&gt; mövzuları üçün quraşdırma, seçmə&lt;br&gt; və tənzimləmə</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="3011"/>
        <source>Author: &lt;a href=&apos;mailto:tsujan2000@gmail.com?Subject=My%20Subject&apos;&gt;Pedram Pourang (aka. Tsu Jan)&lt;/a&gt; &lt;/center&gt;&lt;br&gt;</source>
        <translation>Müəllif: &lt;a href=&apos;mailto:tsujan2000@gmail.com?Subject=My%20Subject&apos;&gt;Pedram Pourang (aka. Tsu Jan)&lt;/a&gt; &lt;/center&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="52"/>
        <source>modified</source>
        <translation>dəyişdirilmiş</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="53"/>
        <source>default</source>
        <translation>ilkin</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="528"/>
        <source>This directory cannot be removed:</source>
        <translation>Bu qovluq silinə bilməz:</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="535"/>
        <source>You might want to investigate the cause.</source>
        <translation>Səbəbi araşdırmaq istəyə bilərsiniz.</translation>
    </message>
    <message>
        <location filename="../../KvantumManager.cpp" line="1008"/>
        <location filename="../../KvantumManager.cpp" line="2249"/>
        <location filename="../../KvantumManager.cpp" line="2722"/>
        <source>Active theme:</source>
        <translation>Cari mövzu:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../main.cpp" line="111"/>
        <source>Kvantum</source>
        <translation>Kvantum</translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="112"/>
        <source>Kvantum is not installed on your system.</source>
        <translation>Kvantum sisteminizə quraşdırılmayıb.</translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="113"/>
        <source>Please first install the Kvantum style plugin!</source>
        <translation>Öncə Kvantum üslub palqinini quraşdırın!</translation>
    </message>
</context>
</TS>
